package com.shankar.project.paymentservice.event;

import com.shankar.project.paymentservice.PaymentStatus;


public class PaymentCompleteEvent {
    private PaymentStatus status;
    private Long orderId;

    public PaymentStatus getStatus() {
        return status;
    }

    public void setStatus(PaymentStatus status) {
        this.status = status;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
}
