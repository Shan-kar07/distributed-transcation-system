package com.shankar.project.paymentservice;

public enum PaymentStatus {
    PENDING,
    COMPLETED,
    FAILED
}
