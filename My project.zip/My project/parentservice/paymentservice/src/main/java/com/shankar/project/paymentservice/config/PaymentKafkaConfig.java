package com.shankar.project.paymentservice.config;

import com.shankar.project.orderservice.event.OrderCreatedEvent;
import com.shankar.project.paymentservice.event.PaymentCompleteEvent;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

public class PaymentKafkaConfig
{
    @Bean
    public KafkaTemplate<String, PaymentCompleteEvent> kafkaTemplate(ProducerFactory<String, PaymentCompleteEvent> producerFactory) {
        return new KafkaTemplate<>(producerFactory);
    }
}
