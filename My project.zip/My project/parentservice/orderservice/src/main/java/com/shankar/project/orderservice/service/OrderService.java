package com.shankar.project.orderservice.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shankar.project.orderservice.OrderStatus;
import com.shankar.project.orderservice.event.OrderCreatedEvent;
import com.shankar.project.orderservice.model.Orders;
import com.shankar.project.orderservice.repository.OrderRepository;
import jakarta.ws.rs.core.HttpHeaders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.MediaType;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {
    private static final Logger log = LoggerFactory.getLogger(OrderService.class);
    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private KafkaTemplate<String, OrderCreatedEvent> kafkaTemplate;

    private final WebClient webClient;

    // Update with your Keycloak details
    private final String clientId = "spring-client-security";
    private final String clientSecret = "sNwKHEXBf76kugm6OaTAQ1u8u5WhILHC";
    private final String tokenUrl = "http://localhost:8181/realms/spring-boot-relm/protocol/openid-connect/token";

    public OrderService(WebClient webClient){
        this.webClient= WebClient.builder().build();
    }

    public List<Orders> findAllOrders() {
        return orderRepository.findAll();
    }

    public Orders addOrders(Orders order) {


        try {
            OrderCreatedEvent orderCreatedEvent = new OrderCreatedEvent();
            orderCreatedEvent.setOrderId(order.getId());
            orderCreatedEvent.setUserId(order.getUserId());
            orderCreatedEvent.setProductId(order.getProductId());
            orderCreatedEvent.setQuantity(order.getQuantity());
            orderCreatedEvent.setStatus(order.getStatus());
            Orders savedOrder = orderRepository.save(order);
            orderCreatedEvent.setId(savedOrder.getId());
            // Send the event to Kafka
            kafkaTemplate.send("orderCreatedTopic1", orderCreatedEvent);
            return savedOrder;
            // Ensure the topic name matches
        } catch (Exception e) {
            throw new RuntimeException("Failed to send Kafka message", e);
        }


    }

    public List<Orders> orderByName(Integer userId) {
        return orderRepository.findByuserId(userId);
    }

    public String deleteById(Long id) {
        try {
            orderRepository.deleteById(id);
            return orderRepository.existsById(id) ? "Record not deleted" : "Deleted the record successfully";
        } catch (EmptyResultDataAccessException e) {
            return "Record not found";
        }
    }

    public Orders updateOrderByState(Long id, String updateStatus) {
        Optional<Orders> toUpdateOrder = orderRepository.findById(id);
        if (toUpdateOrder.isPresent()) {
            OrderCreatedEvent orderCreatedEvent = new OrderCreatedEvent();
            String trimmedStatus = updateStatus.replaceAll("\"", "").trim();
            OrderStatus newStatus = OrderStatus.valueOf(trimmedStatus);
            Orders order = toUpdateOrder.get();
            order.setStatus(newStatus);
            Orders savedorder= orderRepository.save(order);
            orderCreatedEvent.setProductId(savedorder.getProductId());
            orderCreatedEvent.setQuantity(savedorder.getQuantity());
            orderCreatedEvent.setStatus(savedorder.getStatus());
            if(savedorder.getStatus().equals(OrderStatus.COMPLETED)) {
                upadateinventory(orderCreatedEvent);
            }else{
                log.info("The payement has falied");
            }
            return savedorder;
        }
        throw new RuntimeException("Order not found");
    }

    private void upadateinventory(OrderCreatedEvent orderCreatedEvent) {
        getAccessToken()
                .flatMap(token -> {
                    System.out.println("Using Access Token: " + token); // Log token for debugging
                    return webClient.put()
                            .uri("http://localhost:8080/inventory/product/"+orderCreatedEvent.getProductId()+"/update-stock?quantity="+orderCreatedEvent.getQuantity())
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + token) // Use the retrieved token
                            .contentType(MediaType.APPLICATION_JSON)
                            .retrieve()
                            .bodyToMono(Void.class);
                }).subscribe();
    }

    private Mono<String> getAccessToken() {
        return webClient.post()
                .uri(tokenUrl)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .bodyValue("grant_type=client_credentials&client_id=" + clientId + "&client_secret=" + clientSecret)
                .retrieve()
                .bodyToMono(String.class)
                .flatMap(response -> {
                    try {
                        JsonNode jsonNode = new ObjectMapper().readTree(response);
                        return Mono.just(jsonNode.get("access_token").asText()); // Extract the access token
                    } catch (Exception e) {
                        return Mono.error(e); // Handle parsing error
                    }
                })
                .doOnSuccess(token -> System.out.println("Access Token: " + token)) // Log for debugging
                .onErrorResume(error -> {
                    System.err.println("Failed to retrieve access token: " + error.getMessage());
                    return Mono.empty(); // Handle error gracefully
                });
    }
}
