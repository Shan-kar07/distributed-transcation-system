package com.shankar.project.orderservice.controller;


import com.shankar.project.orderservice.OrderStatus;
import com.shankar.project.orderservice.model.Orders;

import com.shankar.project.orderservice.service.OrderService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("orders")
public class OrderController {
    OrderService orderService;
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }
    @GetMapping("/allorders")
    public List<Orders> findAllOrders(){
        return orderService.findAllOrders();

    }
    @PostMapping("/addorders")
    public ResponseEntity<Orders> addOrders(@RequestBody Orders orders){
       return new ResponseEntity<>(orderService.addOrders(orders),HttpStatus.CREATED);

    }
    @GetMapping("/byuserId/{userId}")
    public ResponseEntity<List<Orders>> orderByName(@PathVariable Integer userId){
        return  new ResponseEntity<>(orderService.orderByName(userId), HttpStatus.OK);
    }
    @DeleteMapping("/deletebyid/{id}")
    public ResponseEntity<String> deleteById (@PathVariable Long id){
        return  new ResponseEntity<>(orderService.deleteById(id),HttpStatus.OK);
    }
    @PutMapping("/{id}/updatestate")
    public ResponseEntity<Orders> updateOrderByState(@PathVariable Long id,@RequestBody String status){

        return  new ResponseEntity<>(orderService.updateOrderByState(id, status),HttpStatus.OK);
    }
}
