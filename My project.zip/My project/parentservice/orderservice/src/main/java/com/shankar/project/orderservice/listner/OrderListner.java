//package com.shankar.project.orderservice.listner;
//import com.shankar.project.orderservice.service.OrderService;
//import com.shankar.project.paymentservice.PaymentStatus;
//import com.shankar.project.paymentservice.event.PaymentCompleteEvent;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Lazy;
//import org.springframework.kafka.annotation.KafkaListener;
//@Lazy
//public class OrderListner {
//    private static final Logger log = LoggerFactory.getLogger(OrderListner.class);
//
//    @Autowired
//    OrderService orderService;
//
//    @KafkaListener(topics = "paymentCompleteTopic1", groupId = "payment-complete-group",containerFactory = "kafkaListenerContainerFactory")
//    public void listener(PaymentCompleteEvent event) {
//        if (event == null) {
//            log.error("Received null event");
//            return;
//        }
//
//        Long id = event.getOrderId();
//        PaymentStatus status = event.getStatus();
//        String statusString = status.name(); // This gives you the enum name as a string
//        log.info("the problem is in the if");
//        try {
//            if (PaymentStatus.COMPLETED.equals(status)) {
//                log.info("Processing completed payment for order ID: {}", id);
//                orderService.updateOrderByState(id, statusString);
//                log.info("Payment for order ID: {} has been COMPLETED", id);
//            } else {
//                log.info("Processing failed payment for order ID: {}", id);
//                orderService.updateOrderByState(id, statusString);
//                log.info("Payment for order ID: {} has FAILED", id);
//            }
//        } catch (Exception e) {
//            log.error("Error updating order status for order ID: {}", id, e);
//        }
//    }
//}
