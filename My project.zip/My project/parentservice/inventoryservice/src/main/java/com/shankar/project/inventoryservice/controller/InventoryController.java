package com.shankar.project.inventoryservice.controller;

import com.shankar.project.inventoryservice.model.Inventory;
import com.shankar.project.inventoryservice.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/inventory")
public class InventoryController {
    @Autowired
    private InventoryService inventoryService;
    @GetMapping("/product/{productId}")
    public ResponseEntity<Inventory> getInventoryByProduct(@PathVariable Long productId) {
        return inventoryService.getInventoryByProduct(productId)
                .map(inventory -> new ResponseEntity<>(inventory, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
    @PutMapping("/product/{productId}/update-stock")
    public ResponseEntity<Inventory> updateStock(@PathVariable Long productId, @RequestParam int quantity) {
        Inventory updatedInventory = inventoryService.updateStock(productId, quantity);
        return new ResponseEntity<>(updatedInventory, HttpStatus.OK);
    }
    @PutMapping("/product/{productId}/update-stockup")
    public ResponseEntity<Inventory> updateStockup(@PathVariable Long productId, @RequestParam Integer quantity) {
        Inventory updatedInventory = inventoryService.updateStockup(productId, quantity);
        return new ResponseEntity<>(updatedInventory, HttpStatus.OK);
    }
    @PostMapping("/putproduct")
    public ResponseEntity<Inventory> putproduct(@RequestBody Inventory inventory){
        return new ResponseEntity<>(inventoryService.putproduct(inventory),HttpStatus.CREATED);
    }
}
