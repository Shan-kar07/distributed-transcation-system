package com.shankar.project.paymentservice.listner;

import com.shankar.project.orderservice.OrderStatus;
import com.shankar.project.orderservice.event.OrderCreatedEvent;
import com.shankar.project.paymentservice.model.Payment;
import com.shankar.project.paymentservice.service.PaymentService;

import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
//public class PaymentConsumer {
//
//    private static final Logger log = LoggerFactory.getLogger(PaymentConsumer.class);
//    @Value("${kafka.bootstrap-servers}")
//    private String bootstrapServers;
//
//    @KafkaListener(topics = "orderCreatedTopic1", groupId = "payment-group")
//    public void consumeOrderCreatedEvent(OrderCreatedEvent event) {
//        try {
//            System.out.println("Processing payment for order: " + event.getOrderId());
//            log.info("The order has been received");
//        } catch (Exception e) {
//            // Log the error or handle it accordingly
//            System.err.println("Error processing payment for order: " + event.getOrderId());
//            e.printStackTrace();
//        }
//    }
//
//    @Bean
//    public DefaultErrorHandler errorHandler() {
//        return new DefaultErrorHandler((record, exception) -> {
//            // Log the error information
//            System.err.printf("Error processing record %s due to %s%n", record, exception.getMessage());
//            if (exception.getCause() instanceof org.apache.kafka.common.protocol.types.SchemaException) {
//                System.err.println("Schema error: " + exception.getCause().getMessage());
//            }
//        });
//    }
//
//    @Bean
//    public ConsumerFactory<String, OrderCreatedEvent> consumerFactory() {
//        Map<String, Object> props = new HashMap<>();
//        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
//        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.StringDeserializer.class);
//        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer.class.getName());
//        props.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, JsonDeserializer.class.getName());
//        props.put(JsonDeserializer.VALUE_DEFAULT_TYPE, OrderCreatedEvent.class.getName());
//        props.put(JsonDeserializer.TRUSTED_PACKAGES, "*"); // Adjust according to your package structure for security
//        props.put(ConsumerConfig.GROUP_ID_CONFIG, "payment-group");
//        return new DefaultKafkaConsumerFactory<>(props);
//    }
//
//    @Bean
//    public ConcurrentKafkaListenerContainerFactory<String, OrderCreatedEvent> kafkaListenerContainerFactory() {
//        ConcurrentKafkaListenerContainerFactory<String, OrderCreatedEvent> factory =
//                new ConcurrentKafkaListenerContainerFactory<>();
//        factory.setConsumerFactory(consumerFactory());
//        factory.setCommonErrorHandler(errorHandler()); // Set the error handler
//        return factory;
//    }
//
//}
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Component;

@Component
public class PaymentConsumer {
    @Autowired
    PaymentService paymentService;
    private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(PaymentConsumer.class);

    @KafkaListener(topics = "orderCreatedTopic1", groupId = "payment-group")
    public void listen(OrderCreatedEvent event) {
        try{
            OrderStatus orderedstatus=event.getStatus();
            if (orderedstatus.equals(OrderStatus.PENDING)){
                log.info("The order payment has to be completed");
                Payment payments=new Payment();
                payments.setOrderId(event.getId());
                payments.setAmount(event.getQuantity());
                payments.setTransactionId(generateRandomTransactionId());
                Payment pay=paymentService.initiatePayment(payments);
                log.info("Payment initiated");

            }
        }catch (Exception ignored ){

        }
    }
    public static String generateRandomTransactionId() {
        Random random = new Random();
        int numericId = 1000000 + random.nextInt(9000000); // Generates a random number between 1000000 and 9999999
        int numericSuffix = 1 + random.nextInt(10); // Generates a random number between 1 and 10
        return String.format("TRANS_%d_%d", numericId, numericSuffix);
    }
}

