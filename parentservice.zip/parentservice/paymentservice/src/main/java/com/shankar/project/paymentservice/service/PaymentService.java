package com.shankar.project.paymentservice.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shankar.project.paymentservice.PaymentStatus;
import com.shankar.project.paymentservice.event.PaymentCompleteEvent;
import com.shankar.project.paymentservice.model.Payment;
import com.shankar.project.paymentservice.repository.PaymentRepository;
import jakarta.ws.rs.core.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Optional;

@Service
public class PaymentService {
    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private KafkaTemplate<String, PaymentCompleteEvent> kafkaTemplate;

    private final WebClient webClient;

    // Update with your Keycloak details
    private final String clientId = "spring-client-security"; // Replace with actual client ID
    private final String clientSecret = "oB7AxOE3sPZbH2ekSJE4xNoiKc9fQqwO"; // Replace with actual client secret
    private final String tokenUrl = "http://localhost:8181/realms/spring-boot-relm/protocol/openid-connect/token";

    @Autowired
    public PaymentService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    public Payment initiatePayment(Payment payment) {
        payment.setStatus(PaymentStatus.PENDING);
        return paymentRepository.save(payment);
    }

    public Optional<Payment> getPaymentByOrderId(Long orderId) {
        return paymentRepository.findByOrderId(orderId);
    }

    public Payment updatePaymentStatus(Long paymentId, String status) {
        Optional<Payment> paymentOptional = paymentRepository.findById(paymentId);
        if (paymentOptional.isPresent()) {
            PaymentCompleteEvent paymentCompleteEvent = new PaymentCompleteEvent();
            String trimmedStatus = status.replaceAll("\"", "").trim();
            PaymentStatus updateStatus = PaymentStatus.valueOf(trimmedStatus);
            Payment payment = paymentOptional.get();
            payment.setStatus(updateStatus);
            Payment updatedPayment = paymentRepository.save(payment);
            if (updatedPayment == null) {
                throw new RuntimeException("Failed to update payment.");
            }
            paymentCompleteEvent.setStatus(updatedPayment.getStatus());
            paymentCompleteEvent.setOrderId(updatedPayment.getOrderId());
            updateOrderState(paymentCompleteEvent); // Pass the event object
            return updatedPayment;
        } else {
            throw new RuntimeException("Payment not found");
        }
    }

    private void updateOrderState(PaymentCompleteEvent paymentCompleteEvent) {
        getAccessToken()
                .flatMap(token -> {
                    System.out.println("Using Access Token: " + token); // Log token for debugging
                    return webClient.put()
                            .uri("http://localhost:8080/orders/{orderId}/updatestate", paymentCompleteEvent.getOrderId())
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + token) // Use the retrieved token
                            .contentType(MediaType.APPLICATION_JSON)
                            .body(BodyInserters.fromValue("\"" + paymentCompleteEvent.getStatus().name() + "\"")) // Ensure JSON format
                            .retrieve()
                            .bodyToMono(Void.class);
                }).subscribe();
    }

    private Mono<String> getAccessToken() {
        return webClient.post()
                .uri(tokenUrl)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .bodyValue("grant_type=client_credentials&client_id=" + clientId + "&client_secret=" + clientSecret)
                .retrieve()
                .bodyToMono(String.class)
                .flatMap(response -> {
                    try {
                        JsonNode jsonNode = new ObjectMapper().readTree(response);
                        return Mono.just(jsonNode.get("access_token").asText()); // Extract the access token
                    } catch (Exception e) {
                        return Mono.error(e); // Handle parsing error
                    }
                })
                .doOnSuccess(token -> System.out.println("Access Token: " + token)) // Log for debugging
                .onErrorResume(error -> {
                    System.err.println("Failed to retrieve access token: " + error.getMessage());
                    return Mono.empty(); // Handle error gracefully
                });
    }
}
