//package com.shankar.project.inventoryservice.listner;
//
//import com.shankar.project.inventoryservice.service.InventoryService;
//import com.shankar.project.orderservice.OrderStatus;
//import com.shankar.project.orderservice.event.OrderCreatedEvent;
//import com.shankar.project.paymentservice.PaymentStatus;
//import com.shankar.project.paymentservice.event.PaymentCompleteEvent;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
//
//public class InventoryListner {
//    private static final Logger log = LogManager.getLogger(InventoryListner.class);
//    @Autowired
//    InventoryService inventoryService;
//    @KafkaListener(topics = "inventoryUpdateTopic1",groupId = "inventory-update-group")
//    public void listner(OrderCreatedEvent event){
//        if(event.getStatus().equals(OrderStatus.COMPLETED)){
//            Integer id= event.getProductId();
//            Long productId= id.longValue();
//            OrderStatus status=event.getStatus();
//            int quantity= Math.toIntExact(event.getQuantity());
//            inventoryService.updateStock(productId,quantity);
//            log.info("Order and payment is successfully completed,Inventory is updated");
//        }else{
//            log.info("Order has been Failed so the inventory has not been updated");
//        }
//    }
//}
