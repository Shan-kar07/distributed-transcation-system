package com.shankar.project.inventoryservice.service;

import com.shankar.project.inventoryservice.model.Inventory;
import com.shankar.project.inventoryservice.repository.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class InventoryService {
    @Autowired
    private InventoryRepository inventoryRepository;
    public Inventory updateStock(Long productId, int quantity) {
        Optional<Inventory> inventoryOptional = inventoryRepository.findByProductId(productId);
        if (inventoryOptional.isPresent()) {
            Inventory inventory = inventoryOptional.get();
            inventory.setStockLevel(inventory.getStockLevel() - quantity);
            return inventoryRepository.save(inventory);
        }
        throw new RuntimeException("Product not found");
    }
    public Optional<Inventory> getInventoryByProduct(Long productId) {
        return inventoryRepository.findByProductId(productId);
    }
    public Inventory putproduct (Inventory inventory){
        return inventoryRepository.save(inventory);
    }
    public Inventory updateStockup(Long productId, Integer quantity) {
        Optional<Inventory> inventoryOptional = inventoryRepository.findByProductId(productId);
        if (inventoryOptional.isPresent()) {
            Inventory inventory = inventoryOptional.get();
            inventory.setStockLevel(quantity);
            return inventoryRepository.save(inventory);
        }
        throw new RuntimeException("Product not found");
    }
}
