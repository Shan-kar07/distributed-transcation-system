package com.shankar.project.orderservice.repository;


import com.shankar.project.orderservice.model.Orders;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OrderRepository extends JpaRepository<Orders,Long> {
public  List<Orders> findByuserId(Integer userId);
}